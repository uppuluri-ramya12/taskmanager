const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("./db");
const auth = require("./authMiddleware");

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "secretkey";


router.post("/register", (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const hashed = bcrypt.hashSync(password, 8);

  db.query(
    "INSERT INTO users (name,email,password) VALUES (?,?,?)",
    [name, email, hashed],
    (err) => {
      if (err) {
        return res.status(500).json({ error: "Registration failed" });
      }
      res.json({ message: "User Registered" });
    }
  );
});


router.post("/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password required" });
  }

  db.query(
    "SELECT * FROM users WHERE email=?",
    [email],
    (err, result) => {
      if (err) return res.status(500).json({ error: "Login failed" });
      if (!result || result.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      const valid = bcrypt.compareSync(password, result[0].password);
      if (!valid) return res.status(401).json({ error: "Invalid password" });

      const token = jwt.sign({ id: result[0].id }, JWT_SECRET);
      res.json({ token });
    }
  );
});


router.post("/tasks", auth, (req, res) => {
  const { title, description } = req.body || {};
  if (!title) return res.status(400).json({ error: "Title is required" });

  db.query(
    "INSERT INTO tasks (title,description,user_id) VALUES (?,?,?)",
    [title, description || "", req.user.id],
    (err) => {
      if (err) return res.status(500).json({ error: "Task add failed" });
      res.json({ message: "Task Added" });
    }
  );
});


router.get("/tasks", auth, (req, res) => {
  db.query(
    "SELECT * FROM tasks WHERE user_id=?",
    [req.user.id],
    (err, result) => {
      if (err) return res.status(500).json({ error: "Fetch failed" });
      res.json(result);
    }
  );
});

module.exports = router;
